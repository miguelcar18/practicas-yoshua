Everything you are looking to start a new Laravel Project! 

To install the application visit Installation Guide at http://support.wmlab.in/support/solutions/folders/17000098173

The documentation is available online & it is available at http://support.wmlab.in

Please note that support is available only to the client who have purchased the application from Code Canyon & have a valid purchase code It is also valid for a valid support period. Initially 6 month support is included when you purchase the application. You can always renew your support.

Item support includes:
-------------------------------------------------------
Availability of the author to answer questions
Answering technical questions about item�s features
Assistance with reported bugs and issues
Help with included 3rd party assets

However, item support does not include:
-------------------------------------------------------
Customization services
Installation services

IF YOU HAVE PURCHASING REGULAR LICENSE, THEN PLEASE NOTE THAT YOU WILL BE ABLE TO INSTALL THE APPLICATION ONLY AT ONE LOCATION AT A TIME. IF YOU WANT TO MOVE IT TO ANY OTHER LOCATION, YOU CAN RELEASE LICENSE FROM EXISTING LOCATION AND THEN INSTALL IT ON ANY OTHER LOCATION. FOR DETAILS VISIT LICENSE USAGE TERMS.

All rights reserved to WMLab www.wmlab.in