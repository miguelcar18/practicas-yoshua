<?php
	return array(
		'manage-configuration' => 'configuration',
		'manage-language' => 'language',
		'change-language' => 'language',
		'manage-backup' => 'backup',
		'manage-template' => 'template',
		'manage-ip-filter' => 'ip-filter',
		'manage-custom-field' => 'custom-field',
		'manage-permission' => 'permission',
		'manage-todo' => 'to_do',
		'manage-role' => 'role',
		'manage-user' => 'user',
		'create-user' => 'user',
		'update-user' => 'user',
		'delete-user' => 'user',
		'reset-user-password' => 'user',
		'email-user' => 'user',
		'change-user-status' => 'user',
		'manage-email-log' => 'template',
		'manage-message' => 'message'
		);
?>