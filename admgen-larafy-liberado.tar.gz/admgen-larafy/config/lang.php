<?php return array (
  'en' => 
  array (
    'language' => 'English',
    'calendar' => 'en',
    'datatable' => 'English',
    'datetimepicker' => 'en',
    'datepicker' => 'en',
    'validation' => 'en',
  ),
  'es' => 
  array (
    'language' => 'Español',
    'calendar' => 'ar',
    'datatable' => 'Spanish',
    'datetimepicker' => 'bg',
    'datepicker' => 'ar',
    'validation' => 'bn_BD',
  ),
);