<?php
return array(
'user-registration-form' => 'User Registration Form',
'user-social-form' => 'User Social Form',
);