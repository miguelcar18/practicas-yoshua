<?php
return array(
	'template/*' => array('body'),
	'message' => array('body'),
	'message-reply/*' => array('body'),
	'message-forward/*' => array('body'),
	);