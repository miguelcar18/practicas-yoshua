@include('guest_layouts.head')

<body>
    
    @include('guest_layouts.header_install')
    
    @yield('content')

@include('guest_layouts.foot')