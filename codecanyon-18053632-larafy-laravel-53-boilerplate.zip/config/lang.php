<?php return array (
  'en' => 
  array (
    'language' => 'English',
    'calendar' => 'en',
    'datatable' => 'English',
    'datetimepicker' => 'en',
    'datepicker' => 'en',
    'validation' => 'en',
  ),
);