<?php return array (
    'welcome_email' => array(
        'fields' => 'NAME, USERNAME, EMAIL, PASSWORD'
      ),
);